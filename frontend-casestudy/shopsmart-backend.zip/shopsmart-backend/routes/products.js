import { Router } from "express";
import Product from "../models/Product.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();

// GET /api/products?search=shoe&category=shoes&page=1&limit=12
router.get("/", async (req, res) => {
  const { search, category, page = 1, limit = 12 } = req.query;
  const q = {};
  if (search) q.name = { $regex: search, $options: "i" };
  if (category) q.category = category;
  const [items, total] = await Promise.all([
    Product.find(q).skip((page - 1) * limit).limit(+limit).sort("-createdAt"),
    Product.countDocuments(q),
  ]);
  res.json({ items, total, page: +page, pages: Math.ceil(total / limit) });
});

router.get("/:id", async (req, res) => {
  const p = await Product.findById(req.params.id);
  p ? res.json(p) : res.status(404).json({ message: "Not found" });
});

router.post("/", protect, adminOnly, async (req, res) =>
  res.status(201).json(await Product.create(req.body)));

router.put("/:id", protect, adminOnly, async (req, res) =>
  res.json(await Product.findByIdAndUpdate(req.params.id, req.body, { new: true })));

router.delete("/:id", protect, adminOnly, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

export default router;
