import { Router } from "express";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { protect } from "../middleware/auth.js";

const router = Router();
const sign = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "7d" });

router.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (await User.findOne({ email }))
    return res.status(400).json({ message: "Email already registered" });
  const user = await User.create({ name, email, password });
  res.status(201).json({ _id: user._id, name, email, role: user.role, token: sign(user._id) });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !(await user.matchPassword(password)))
    return res.status(401).json({ message: "Invalid credentials" });
  res.json({ _id: user._id, name: user.name, email, role: user.role, token: sign(user._id) });
});

router.get("/me", protect, (req, res) => res.json(req.user));

export default router;
