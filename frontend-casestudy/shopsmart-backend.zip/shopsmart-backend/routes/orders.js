import { Router } from "express";
import Order from "../models/Order.js";
import Product from "../models/Product.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();

// body: { items: [{ product: "<productId>", qty: 2 }] }
router.post("/", protect, async (req, res) => {
  const { items } = req.body;
  if (!items?.length) return res.status(400).json({ message: "Cart is empty" });

  const lines = [];
  let total = 0;
  for (const it of items) {
    const p = await Product.findById(it.product);
    if (!p || p.stock < it.qty)
      return res.status(400).json({ message: `Unavailable: ${p?.name || it.product}` });
    lines.push({ product: p._id, name: p.name, price: p.price, qty: it.qty });
    total += p.price * it.qty;
  }
  for (const l of lines)
    await Product.findByIdAndUpdate(l.product, { $inc: { stock: -l.qty } });

  res.status(201).json(await Order.create({ user: req.user._id, items: lines, total }));
});

router.get("/mine", protect, async (req, res) =>
  res.json(await Order.find({ user: req.user._id }).sort("-createdAt")));

router.get("/", protect, adminOnly, async (req, res) =>
  res.json(await Order.find().populate("user", "name email").sort("-createdAt")));

router.patch("/:id/status", protect, adminOnly, async (req, res) =>
  res.json(await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true })));

export default router;
