import mongoose from "mongoose";

export default mongoose.model(
  "Product",
  new mongoose.Schema(
    {
      name: { type: String, required: true },
      description: String,
      price: { type: Number, required: true, min: 0 },
      category: String,
      image: String,
      stock: { type: Number, default: 0, min: 0 },
    },
    { timestamps: true }
  )
);
